package com.example.fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ProductAdpter extends RecyclerView.Adapter<ProductAdpter.ProductViewHolder> {

    private final List<Product> productList;
    private final OnProductClickListener listener;

    // Interface untuk menangani klik produk
    public interface OnProductClickListener {
        void onProductClick(Product product);
    }

    // Constructor ProductAdapter untuk menerima data dan listener
    public ProductAdpter(List<Product> productList, OnProductClickListener listener) {
        this.productList = productList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate layout item_product untuk setiap item dalam RecyclerView
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_product, parent, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        // Mengambil data produk dari daftar dan menampilkan ke dalam ViewHolder
        Product product = productList.get(position);
        holder.name.setText(product.getName());
        holder.description.setText(product.getDescription());

        // Menambahkan listener untuk item klik
        holder.itemView.setOnClickListener(v -> listener.onProductClick(product));
    }

    @Override
    public int getItemCount() {
        // Mengembalikan jumlah produk dalam daftar
        return productList.size();
    }

    // ViewHolder untuk menyimpan referensi ke elemen layout item_product
    public static class ProductViewHolder extends RecyclerView.ViewHolder {
        TextView name, description;

        public ProductViewHolder(View itemView) {
            super(itemView);
            // Inisialisasi TextView untuk nama dan deskripsi produk
            name = itemView.findViewById(R.id.productName);
            description = itemView.findViewById(R.id.productDescription);
        }
    }
}
